var serialport=require('node-serialport')

var myPort = new serialport.SerialPort("/dev/ttyO3",{
	parser: serialport.parsers.raw,
	baud: 9600
})

console.log("start write ...");
myPort.on("open", function(){
	myPort.write("Hello From AR Drone 2.0"),
	console.log("Hello From AR Drone 2.0"),
	//myPort.write("Hello From AR Drone 2.0"),
	//delay(5);
	//myPort.write("Hello From AR Drone 2.0"),
	myPort.write("Hello From AR Drone 2.0")
})

console.log("end");
