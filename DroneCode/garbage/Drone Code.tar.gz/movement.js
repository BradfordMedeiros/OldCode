//@TODO:  Everything
//@TODO:  Testing
//@TODO:  Documentation

/**
	This is the gps module.  It should publish to location.  subscribe to nothing
	Just placeholder code for now

	**/  

function _movement(bootstrapper){
	this.name = "movement";
	bootstrapper.addPublisherToTopic("location", this);	// fix this
}

_movement.prototype.getLocation = function(){
	return "CODE THE GPS LOL";
}
